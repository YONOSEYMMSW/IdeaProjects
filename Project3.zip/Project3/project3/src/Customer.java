import java.util.ArrayList;

public class Customer {
    private String firstName;
    private String lastName;
    private int PIN;
    ArrayList<Account> customerAccountList = new ArrayList<Account>();

    public Customer(String firstName, String lastName, int PIN) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.PIN = PIN;
    }

    public void addAccount(Account account){
        customerAccountList.add(account);
    }

    public void removeAccount(Account account){
        customerAccountList.remove(account);
    }

    public Account getAccountData( int accountNumber){
        Account customerAccountInfo = null;
        for(Account b : customerAccountList){
            if(b.getAccountNumber(accountNumber) == (accountNumber)){
                customerAccountInfo = b;
                break;
            }
        }
        return customerAccountInfo;
    }

    public StringBuilder getAllTheAccounts(){
        StringBuilder customerStringBuilder = new StringBuilder();

        for(Account k : customerAccountList){
            customerStringBuilder.append(k.toString());
        }
        return customerStringBuilder;
    }

    public int getPIN(int PIN) {
        return this.PIN;
    }

    public void setPIN(int PIN) {
        this.PIN = PIN;
    }

    @Override
    public String toString() {
        return
                '\n' + "Customer name: " + firstName + ' ' + lastName + '\n' +
                "PIN: " + PIN
                ;
    }
}
